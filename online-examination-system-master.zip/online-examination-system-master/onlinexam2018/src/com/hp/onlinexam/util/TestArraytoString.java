package com.hp.onlinexam.util;

import java.util.ArrayList;
import java.util.List;

public class TestArraytoString {

	public static void main(String[] args) {
		List list = new ArrayList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		
	}
}
