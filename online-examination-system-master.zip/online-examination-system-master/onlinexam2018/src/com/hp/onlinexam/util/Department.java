package com.hp.onlinexam.util;

public enum Department {
	开发,
	测试,
	家里蹲,
	中二病,
	逗比美学,
	魔法,
	计算机科学与技术,
	软件工程,
	单片机,
	动漫,
	ACG
}
